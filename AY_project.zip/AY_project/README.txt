@Author William Hoyt
@Version 1
@Description 
'''
    This is my creative project for Astronomy 101. This was a fun self-made project on
    myself. I wanted to tie my major into something multi-purpose for this class as well as
    gain the skills to make a GUI/Data Labeler. This was aimed to be a sort of "quiz" type 
    communication between the teacher (Admin) and the student (Client) to see if they know the
    key points on some Astronomy Pictures of the Day. 

    Some key notes:
    1. There are two features that I am missing:
        i. the client cannot click on the squares to answer "What are you looking at?" This 
        was a big deal because this is what combines the communication and makes this useful
        for classroom use however due to lack of knowledge and time I couldn't figure it out.
        ii. I have no idea how to make a .exe for this since I spaced on the fact that I have
        show that it works
    2. Everything for Admin is Done. I got everything I wanted from Admin. A nice clean UI that 
    creates the boxes, creates a easy to use UI/UX, and saves the data automatically. 
    3. There is a lot more I would love to add to what I already have however, I lack the time
    at this moment and this is at a point where I can be proud of what I made.
'''