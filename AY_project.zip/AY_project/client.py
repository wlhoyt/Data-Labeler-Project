import sys
import json
from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QWidget, QLabel,  QMainWindow,  QAction, QMenu, QGraphicsView, QGraphicsScene, QGraphicsEllipseItem
from PyQt5.QtGui import QIcon, QPixmap, QPainter
from PyQt5.QtCore import QPoint, Qt, QPointF


class App(QWidget):

    def __init__(self):
        super().__init__()
        self.title  = 'Client'
        self.left = 10
        self.top = 10
        self.width = 640
        self.height = 480
        self.setGeometry(self.left, self.top, self.width, self.height)
        self.begin = QtCore.QPoint()
        self.end = QtCore.QPoint()
        self.image = str(sys.argv[1])
        self.loadContents()
        self.flag = 0
        self.show()
        self.index
        self.labels 


    #Creates the image and allows for the image to be drawn on
    def paintEvent(self, event):
        label = QLabel(self)
        pixmap = QPixmap(self.image)
        label.setPixmap(pixmap)

        qp = QtGui.QPainter(self)
        br = QtGui.QBrush(QtGui.QColor(0, 255, 255, 60)) 
        self.resize(pixmap.width(),pixmap.height())
        qp.drawPixmap(self.rect(),pixmap)
        qp.setBrush(br)   
        qp.drawRect(QtCore.QRect(self.begin, self.end))
        if self.index > 0:
            for num in self.labels:
                first = QPoint(num['b_x'],num['b_y'])
                second = QPoint(num['e_x'],num['e_y'])
                qp.drawRect(QtCore.QRect(first,second))

        
    def loadContents(self):
        f = open('infromation.txt','r')
        d = {}
        l = []
        i = 0
        for x in f:
            d = json.loads(x)
            l.append(d)
            i = i +1
        self.index = i
        self.labels = l
        f.close()
    def contextMenuEvent(self, event):
        contextMenu = QMenu(self)
        quitAct = contextMenu.addAction("Quit")
        action = contextMenu.exec_(self.mapToGlobal(event.pos()))
        if action == quitAct:
            self.close()

# Selection
# popup with buttons from admin
# Give feedback
# Save Results
# Block Repeats

 
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = App()
    ex.show()
    sys.exit(app.exec_())
    